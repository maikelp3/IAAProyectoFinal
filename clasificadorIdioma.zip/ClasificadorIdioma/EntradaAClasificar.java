package entrada;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import aplicacion.BaseConocimiento;

public class EntradaAClasificar {

  private String [] entrada;
  private BaseConocimiento baseConocimiento;

  public EntradaAClasificar (BaseConocimiento bc) {
    setBaseConocimiento (bc);
  }

  public void cargarEntrada (String fichero) {
    final String blancos = "\\s";
    try {
      BufferedReader bf = new BufferedReader (new FileReader (fichero));
      String linea = bf.readLine ();
      setEntrada (linea.split (blancos));
      bf.close ();
      
    } catch (IOException io) {
      io.printStackTrace ();
    }
  }

  public String clasificarEntrada () {
    double frecEsp = 0.0;
    double frecIng = 0.0;
    String resultado = "default";
    for (int i = 0; i < getEntrada ().length; ++i) {
     
      if (getBaseConocimiento ().getTokens_es ().size () > 0) {
        for (int j = 0; j < getBaseConocimiento ().getTokens_es ().size (); ++j) {
          if (getBaseConocimiento ().getTokens_es ().get (j).getLexema ().equals (getElementoEntrada (i)))
            frecEsp += getBaseConocimiento ().getTokens_es ().get (j).getFrecuencia ();
        }
      }

      if (getBaseConocimiento ().getTokens_in ().size () > 0) {
        for (int j = 0; j < getBaseConocimiento ().getTokens_in ().size (); ++j) {
          if (getBaseConocimiento ().getTokens_in ().get (j).getLexema ().equals (getElementoEntrada (i)))
            frecIng += getBaseConocimiento ().getTokens_in ().get (j).getFrecuencia ();
        }
      }
    }
    if (frecEsp < frecIng) // porque la frec es negativa !!
      resultado = "ESP";
    else if (frecEsp > frecIng)
      resultado = "ING";
    else
      resultado = "IDIOMA_DESCONOCIDO";

    return resultado;
  }

  public String [] getEntrada () { return entrada; }
  public void setEntrada (String [] entrada) { this.entrada = entrada; }
  public String getElementoEntrada (int pos) { return entrada[pos]; }
  
  public BaseConocimiento getBaseConocimiento () { return baseConocimiento; }
  public void setBaseConocimiento (BaseConocimiento baseConocimiento) { this.baseConocimiento = baseConocimiento; }



}
