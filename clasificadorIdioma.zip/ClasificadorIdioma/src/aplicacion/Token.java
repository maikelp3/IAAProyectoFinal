package aplicacion;

public class Token {

  private String lexema;
  private double aparic;
  private double frecuencia;

  public double getAparic () {	return aparic;	}
  public void setAparic (double aparic) {	this.aparic = aparic;	}
  public String getLexema () { return lexema; }
  public void setLexema (String lexema) { this.lexema = lexema; }

  public double getFrecuencia () { return frecuencia; }
  public void setFrecuencia (double frecuencia) { this.frecuencia = frecuencia; }

  public Token (String lex) {
    setAparic (1);
    setFrecuencia (1);
    setLexema (lex);
  }

  public String toString () {
    return "Lexema = " + getLexema () + " , frec = " + getFrecuencia ();
  }

}
