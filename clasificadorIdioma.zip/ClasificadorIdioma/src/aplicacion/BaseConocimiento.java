/**
 * Proyecto Final Inteligencia Artificial Avanzada:
 * Título: Clasificador del idioma (ES - ING).
 * 
 * @author Miguel Pérez Bello
 * @author Guillermo Rodríguez Pardo
 * @author Tinguaro Cubas Saiz
 * 
 * @version 2.1
 * 
 * @file BaseConocimiento.java
 * 
 * Descripción: fichero que aloja la descripción de la base de 
 * conocimiento que se usará para "aprender" un idioma desde una
 * base de datos de twitter para clasificar el idioma en el que
 * están escritos posteriores ficheros que se carguen. 
 */

package aplicacion;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class BaseConocimiento {

  private ArrayList <Token> tokens_es;
  private ArrayList <Token> tokens_in;
  public ArrayList <Token> getTokens_es () { return tokens_es; }
  public void setTokens_es (ArrayList <Token> tokens_es) { this.tokens_es = tokens_es; }

  public ArrayList <Token> getTokens_in () { return tokens_in; }
  public void setTokens_in (ArrayList <Token> tokens_in) { this.tokens_in = tokens_in; }

  public BaseConocimiento () {
    tokens_es = new ArrayList <Token> ();
    tokens_in = new ArrayList <Token> ();
  }

  /**
   * Procedimiento que se encarga de "aprender" el idoma ESP (español)
   * a través de tokenizar una base de datos de "tweets" en español.
   */
  public void cargarFicherosEsp () {
    final String URL = "src/aplicacion/twittercorpus/es_ES/";
    final int NUM_BLOQ_PRIN = 5;
    final int NUM_BLOQ_SEC = 280;
    String ficheroTmp;
    for(int i = 0; i < NUM_BLOQ_PRIN; i++ ) {
      for (int j = 0; j < NUM_BLOQ_SEC; j++) {
        ficheroTmp = URL;
        ficheroTmp += i;
        ficheroTmp += "_";
        ficheroTmp += j;
        ficheroTmp += ".txt";
        try {
          tokenizarArchivoEsp (new FileReader (ficheroTmp));
        } catch (FileNotFoundException e) {
          //e.printStackTrace();
        }
      }  
    }
  }
  

  /**
   * Procedimiento que se encarga de "aprender" el idoma ING (inglés)
   * a través de tokenizar una base de datos de "tweets" en inglés.
   */
  public void cargarFicherosIng () {
    final String URL = "src/aplicacion/twittercorpus/en_UK/";
    final int NUM_BLOQ_PRIN = 4;
    final int NUM_BLOQ_SEC = 280;
    String ficheroTmp;
    for(int i = 0; i < NUM_BLOQ_PRIN; i++ ) {
      for (int j = 0; j < NUM_BLOQ_SEC; j++) {
        ficheroTmp = URL;
        ficheroTmp += i;
        ficheroTmp += "_";
        ficheroTmp += j;
        ficheroTmp += ".txt";
        try {
          tokenizarArchivoIng (new FileReader (ficheroTmp));
        } catch (FileNotFoundException e) {
          //e.printStackTrace();
        }
      }  
    }
  }
  
  /**
   * Procedimiento encargado de tokenizar los ficheros en español
   * para la base de conocimiento.
   */
  public void tokenizarArchivoEsp (FileReader elArchivo) {
    try {
      String [] lineas;
      final String blancos = "\\s";
      BufferedReader bf = new BufferedReader (elArchivo);
      String linea = bf.readLine ();
      lineas = linea.split (blancos);

      for (int k = 0; k < lineas.length; ++k) {
        addTokenEsp (lineas[k]);
      }
      bf.close ();

    } catch (IOException io) {
      io.printStackTrace ();
    }
  }

  /**
   * Procedimiento encargado de tokenizar los ficheros en inglés
   * para la base de conocimiento.
   */
  public void tokenizarArchivoIng (FileReader elArchivo) {
    try {
      String [] lineas;
      final String blancos = "\\s";
      BufferedReader bf = new BufferedReader (elArchivo);
      String linea = bf.readLine ();
      lineas = linea.split (blancos);

      for (int k = 0; k < lineas.length; ++k) {
        addTokenIng (lineas[k]);
      }
      bf.close ();

    } catch (IOException io) {
      io.printStackTrace ();
    }
  }

  /**
   * Procedimiento encargado de añadir los tokens resultantes de
   * tokenizar la base de datos española en su respectivo vector.
   * @param lex
   */
  public void addTokenEsp (String lex) {
    boolean encontrado = false;
    for (int i = 0; i < getTokens_es ().size (); ++i) {
      if (getTokens_es ().get (i).getLexema ().compareTo (lex) == 0) {
        encontrado = true;
        getTokens_es ().get (i).setAparic (getTokens_es ().get (i).getAparic () + 1);
      }
    }
    if (!encontrado)
      getTokens_es ().add (new Token (lex));
  }

  /**
   * Procedimiento encargado de añadir los tokens resultantes de
   * tokenizar la base de datos inglesa en su respectivo vector.
   * @param lex
   */
  public void addTokenIng (String lex) {
    boolean encontrado = false;
    for (int i = 0; i < getTokens_in ().size (); ++i) {
      if (getTokens_in ().get (i).getLexema ().compareTo (lex) == 0) {
        encontrado = true;
        getTokens_in ().get (i).setAparic (getTokens_in ().get (i).getAparic () + 1);
      }
    }
    if (!encontrado)
      getTokens_in ().add (new Token (lex));
  }

  /**
   * Muestra los tokens en español aprendidos por la base
   * de conocimiento.
   */
  public void mostrarTokensEs () {
    for (int i = 0; i < getTokens_es ().size (); ++i) {
      System.out.println (getTokens_es ().get (i));
    }
  }

  /**
   * Muestra los tokens en inglés aprendidos por la base
   * de conocimiento.
   */
  public void mostrarTokensIng () {
    for (int i = 0; i < getTokens_in ().size (); ++i) {
      System.out.println (getTokens_in ().get (i));
    }
  }

  /**
   * Calcula el logaritmo en base 10 de la frecuencia de 
   * aparición de cada token entre el total de tokens, 
   * dato necesario en la tarea de clasificación.
   */
  public void calcularLogaritmoFrec () {
    if (getTokens_es ().size () > 0) {
      for (int i = 0; i < getTokens_es ().size (); ++i) {
        getTokens_es ().get (i).setFrecuencia (
            Math.abs (Math.log10 (getTokens_es ().get (i).getAparic () / 
                getTokens_es ().size ())));
      }
    }

    if (getTokens_in ().size () > 0) {
      for (int i = 0; i < getTokens_in ().size (); ++i) {
        getTokens_in ().get (i).setFrecuencia (
            Math.abs (Math.log10 (getTokens_in ().get (i).getAparic () /
                getTokens_in ().size ())));
      }
    }
  }
}
